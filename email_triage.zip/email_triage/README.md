# 📧 Email Triage Assistant

An AI-powered Streamlit app that automatically classifies, summarizes, and drafts replies to emails — using Claude via the Anthropic API.

## What it demonstrates
- **Prompt engineering** — structured JSON output from a language model
- **AI workflow automation** — classify → summarize → draft in a single pipeline
- **Multi-step chaining** — "Improve draft" sends a second API call on top of the first
- **Streamlit UI** — clean, interactive Python web app with no frontend code

---

## Setup

### 1. Clone / download this project
```bash
cd email_triage
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set your Anthropic API key
Get a key at https://console.anthropic.com

**Mac/Linux:**
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

**Windows (Command Prompt):**
```cmd
set ANTHROPIC_API_KEY=sk-ant-...
```

**Or** create a `.env` file and load it — Streamlit supports this natively:
```
ANTHROPIC_API_KEY=sk-ant-...
```

### 4. Run the app
```bash
streamlit run app.py
```

The app opens at `http://localhost:8501`

---

## How it works

1. You paste an email into the text area
2. The app sends it to Claude with a system prompt that enforces a JSON response schema
3. Claude returns `{ category, confidence, summary, next_action, draft_reply }`
4. The UI renders each field — category badge, summary card, action, and editable draft
5. "Improve draft" chains a *second* API call to refine the reply

---

## Project structure
```
email_triage/
├── app.py            # Main Streamlit app
├── requirements.txt  # Python dependencies
└── README.md         # This file
```

---

## Level-up ideas
- **Batch mode** — process a list of emails from a CSV
- **Gmail integration** — connect via `google-auth` + Gmail API to pull real inbox emails
- **Logging** — save every triage result to a local SQLite DB or CSV
- **Tone presets** — add a sidebar option: formal / casual / assertive
- **Streamlit Cloud deploy** — push to GitHub and deploy free at share.streamlit.io

import streamlit as st
import anthropic
import json

st.set_page_config(page_title="Email Triage Assistant", page_icon="📧", layout="centered")

st.title("📧 Email Triage Assistant")
st.caption("Powered by Claude — classify, summarize, and draft replies automatically.")

# --- Sidebar: user context ---
with st.sidebar:
    st.header("Your Profile")
    user_name = st.text_input("Your name", placeholder="e.g. Sarah")
    user_role = st.text_input("Your role", placeholder="e.g. Product Manager at a startup")
    st.divider()
    st.header("About this app")
    st.markdown(
        "This app uses **prompt chaining** and **structured JSON outputs** "
        "to automate email triage — a common AI workflow pattern.\n\n"
        "**Skills demonstrated:**\n"
        "- Prompt engineering\n"
        "- Structured output parsing\n"
        "- Multi-step AI pipelines\n"
        "- Streamlit UI development"
    )

# --- Example emails ---
EXAMPLES = {
    "🔴 Urgent": """From: cto@company.com
Subject: URGENT - Production server is down

Hey,

Our main production server went down 20 minutes ago. Customers are getting 502 errors. I need you on a call NOW. This is P0. Every minute costs us money.

Call me immediately: 555-0182
- Dan""",

    "🟡 Action needed": """From: hiring@techcorp.io
Subject: Interview invitation - Senior PM role

Hi,

Thanks for applying to TechCorp. We'd love to invite you to a 45-min video interview with our VP of Product.

Could you let us know your availability over the next two weeks? We're flexible on timing.

Best,
Rachel, Talent Team""",

    "🔵 FYI": """From: newsletter@producthunt.com
Subject: Top products this week

Here are the top 10 products launched on Product Hunt this week...
1. AI Writing Tool
2. Design System Generator
3. Calendar Sync App
[continued list...]""",

    "⚫ Spam": """From: noreply@prize-winner123.net
Subject: Congratulations! You've won $5,000

Dear Winner,

You have been selected as this week's lucky prize winner! Click here to claim your $5,000 reward. Limited time offer!

Click here: http://claim-prize.net/winner"""
}

# --- Load example ---
col1, col2 = st.columns([3, 1])
with col1:
    st.subheader("Paste Email")
with col2:
    selected_example = st.selectbox("Load example", ["—"] + list(EXAMPLES.keys()), label_visibility="collapsed")

default_text = EXAMPLES.get(selected_example, "") if selected_example != "—" else ""
email_text = st.text_area("Email content", value=default_text, height=200, placeholder="Paste the full email here...")

# --- Triage function ---
def triage_email(email: str, name: str, role: str) -> dict:
    client = anthropic.Anthropic()

    user_context = ""
    if name or role:
        user_context = f"The recipient is: {name}{', ' + role if role else ''}."

    system_prompt = f"""You are an expert email triage assistant. Analyze emails and return ONLY valid JSON with no markdown, no backticks, no explanation. Return exactly this structure:
{{
  "category": "urgent" | "action_needed" | "fyi" | "spam",
  "confidence": "high" | "medium" | "low",
  "summary": "one sentence summary of the email",
  "next_action": "specific actionable next step for the recipient",
  "draft_reply": "a professional reply appropriate to the email. Empty string if no reply needed."
}}
{user_context}
For spam or fyi, draft_reply can be an empty string."""

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1024,
        system=system_prompt,
        messages=[{"role": "user", "content": f"Triage this email:\n\n{email}"}]
    )

    raw = message.content[0].text.strip()
    clean = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


def improve_draft(draft: str, email: str) -> str:
    client = anthropic.Anthropic()
    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=512,
        messages=[{
            "role": "user",
            "content": f"Improve this email reply to be more professional and concise. Return only the improved reply with no explanation.\n\nOriginal email:\n{email}\n\nDraft reply:\n{draft}"
        }]
    )
    return message.content[0].text.strip()


# --- Badge styling ---
CATEGORY_CONFIG = {
    "urgent":       ("🔴 Urgent",       "#FCEBEB", "#A32D2D"),
    "action_needed":("🟡 Action Needed", "#FAEEDA", "#854F0B"),
    "fyi":          ("🔵 FYI",           "#E6F1FB", "#185FA5"),
    "spam":         ("⚫ Spam",          "#F1EFE8", "#5F5E5A"),
}

# --- Main action ---
if st.button("⚡ Triage this email", type="primary", disabled=not email_text.strip()):
    with st.spinner("Analyzing email..."):
        try:
            result = triage_email(email_text, user_name, user_role)
            st.session_state["result"] = result
            st.session_state["email"] = email_text
        except Exception as e:
            st.error(f"Something went wrong: {e}")

# --- Display results ---
if "result" in st.session_state:
    result = st.session_state["result"]
    email_used = st.session_state["email"]

    st.divider()
    st.subheader("Triage Result")

    cat_key = result.get("category", "fyi")
    label, bg, fg = CATEGORY_CONFIG.get(cat_key, ("Unknown", "#eee", "#333"))

    col_a, col_b, col_c = st.columns(3)
    with col_a:
        st.markdown(f"**Category**")
        st.markdown(
            f'<span style="background:{bg};color:{fg};padding:4px 12px;border-radius:8px;font-size:14px;font-weight:500">{label}</span>',
            unsafe_allow_html=True
        )
    with col_b:
        st.metric("Confidence", result.get("confidence", "—").capitalize())
    with col_c:
        st.metric("Action", result.get("next_action", "—")[:40] + ("…" if len(result.get("next_action","")) > 40 else ""))

    st.markdown("**Summary**")
    st.info(result.get("summary", ""))

    st.markdown("**Next action**")
    st.success(result.get("next_action", ""))

    draft = result.get("draft_reply", "")
    st.markdown("**Draft reply**")
    if draft:
        draft_text = st.text_area("Edit before sending:", value=draft, height=180, key="draft_box")

        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("📋 Copy to clipboard"):
                st.write(f"```\n{draft_text}\n```")
                st.caption("Select the text above to copy.")
        with col2:
            if st.button("✨ Improve draft"):
                with st.spinner("Improving..."):
                    improved = improve_draft(draft_text, email_used)
                    st.session_state["result"]["draft_reply"] = improved
                    st.rerun()
        with col3:
            if st.button("🔄 Re-triage"):
                del st.session_state["result"]
                st.rerun()
    else:
        st.caption("No reply needed for this email.")
